#!/bin/bash
echo "Starting BukkitUI..."
echo "Should any bugs or errors occur, please report them on GitHub or BukkitDev."
java -jar BukkitUI.jar
echo "BukkitUI has exited."
echo "Hit ENTER to exit."
read